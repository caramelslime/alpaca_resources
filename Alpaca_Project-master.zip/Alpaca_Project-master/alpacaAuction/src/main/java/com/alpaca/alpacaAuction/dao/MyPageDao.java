package com.alpaca.alpacaAuction.dao;

public interface MyPageDao {

}
