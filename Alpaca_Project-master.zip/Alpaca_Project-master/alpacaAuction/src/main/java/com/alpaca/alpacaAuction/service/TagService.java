package com.alpaca.alpacaAuction.service;

import java.util.List;

import com.alpaca.alpacaAuction.model.Tag;

public interface TagService {

	List<Tag> list();

	List<Tag> tagList(int tagValue);

}
