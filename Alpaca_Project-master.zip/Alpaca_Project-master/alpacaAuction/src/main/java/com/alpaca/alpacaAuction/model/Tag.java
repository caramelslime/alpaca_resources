package com.alpaca.alpacaAuction.model;

import lombok.Data;

@Data
public class Tag {
	private int tag_no;
	private String tag_name;
}
