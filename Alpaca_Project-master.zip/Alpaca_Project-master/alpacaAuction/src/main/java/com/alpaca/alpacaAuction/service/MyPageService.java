package com.alpaca.alpacaAuction.service;

public interface MyPageService {

}
